# Changelog

## 0.1.0 (2023-04-30)

#### New Features

* add do_cmd() to excute shell commands without quitting gitbetter
* enclose 'message' in quotes if you forget them
#### Refactorings

* rename some shell functions
#### Docs

* update readme
* add future feature to list in readme


## v0.0.0 (2023-04-29)
